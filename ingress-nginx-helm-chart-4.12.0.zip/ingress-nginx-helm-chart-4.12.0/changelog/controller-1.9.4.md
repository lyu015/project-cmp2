# Changelog

### 1.9.4

Images:

* registry.k8s.io/ingress-nginx/controller:v1.9.4@sha256:5b161f051d017e55d358435f295f5e9a297e66158f136321d9b04520ec6c48a3
* registry.k8s.io/ingress-nginx/controller-chroot:v1.9.4@sha256:5976b1067cfbca8a21d0ba53d71f83543a73316a61ea7f7e436d6cf84ddf9b26

### All changes:

* Cherry pick fcgi fix and release v1.9.4 (#10544)

**Full Changelog**: https://github.com/kubernetes/ingress-nginx/compare/controller-controller-v1.9.3...controller-controller-v1.9.4
